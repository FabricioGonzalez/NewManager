package com.kaskin.manager.DataSources

import com.google.gson.Gson
import com.kaskin.manager.Models.LoggedInUser
import com.kaskin.manager.Models.LoginRequest
import com.kaskin.manager.Models.Result
import com.kaskin.manager.Models.UserLoginData
import com.kaskin.manager.Repositories.HTTPRequest
import java.io.IOException

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
class LoginDataSource {

    suspend fun login(username: String, password: String): Result<LoggedInUser> {
        try {

            val requester = HTTPRequest()

            val result = requester.JsonBody(LoginRequest(username, password))
                .sendPostRequest("api/AndroidDb/LoginMobile")

            val gson = Gson()

            val json =
                gson.fromJson(result.toString(), UserLoginData::class.java)
            // TODO: handle loggedInUser authentication
            val fakeUser = LoggedInUser(json.setor.toString(), json.name)
            return Result.Success(fakeUser)
        } catch (e: Throwable) {
            return Result.Error(IOException("Error logging in", e))
        }
    }

    fun logout() {
        // TODO: revoke authentication
    }
}