package com.kaskin.manager.Views.Activities.ui.dados

import android.arch.lifecycle.ViewModel

class DadosViewModel : ViewModel() {

}