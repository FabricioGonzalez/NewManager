package com.kaskin.manager.Views.Activities.ui.communication

import android.arch.lifecycle.ViewModel

class CommunicationViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}