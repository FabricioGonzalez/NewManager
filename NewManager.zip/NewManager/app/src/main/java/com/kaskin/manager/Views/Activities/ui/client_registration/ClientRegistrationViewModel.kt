package com.kaskin.manager.Views.Activities.ui.client_registration

import android.arch.lifecycle.ViewModel

class ClientRegistrationViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}