package com.kaskin.manager.Repositories

import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class HTTPRequest {

    private var reqParam: String = ""
    private var reqBody: String = ""

    private var url: String = "http://srvksk.dyndns.org:7383"
//    private var url: String = "https://192.168.1.192:7132"

    fun SetParameters(key: String, value: String): HTTPRequest {
        reqParam = URLEncoder.encode("username", "UTF-8") + "=" + URLEncoder.encode(key, "UTF-8")
        reqParam += "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(
            value,
            "UTF-8"
        )

        return this
    }

    fun <T> JsonBody(bodyToSerealize: T): HTTPRequest {
        val gson = Gson()
        reqBody = gson.toJson(bodyToSerealize)

        return this
    }

    suspend fun sendPostRequest(route: String): String? {
        return withContext(Dispatchers.IO) {
            val mURL = URL("$url/$route")
            return@withContext with(mURL.openConnection() as HttpURLConnection) {
                // optional default is GET
                requestMethod = "POST"

                doOutput = true

                val wr = OutputStreamWriter(this.outputStream);

                wr.write(reqBody);
                wr.flush();

                println("URL : $url")
                println("Response Code : $responseCode")

                BufferedReader(InputStreamReader(this.inputStream)).use {
                    val response = StringBuffer()

                    var inputLine = it.readLine()
                    while (inputLine != null) {
                        response.append(inputLine)
                        inputLine = it.readLine()
                    }
                    return@withContext response.toString()
                }
            }
        }

    }

    suspend fun sendGetRequest(route: String): StringBuffer {
        return withContext(Dispatchers.IO) {
            try {
                val mURL = URL("$url/$route?" + reqParam)

                return@withContext with(mURL.openConnection() as HttpURLConnection) {
                    // optional default is GET
                    requestMethod = "POST"

                    val wr = OutputStreamWriter(outputStream);
                    wr.write(reqBody);
                    wr.flush();

                    BufferedReader(InputStreamReader(inputStream)).use {
                        val response = StringBuffer()

                        var inputLine = it.readLine()
                        while (inputLine != null) {
                            response.append(inputLine)
                            inputLine = it.readLine()
                        }
                        reqParam = ""

                        return@use response
                    }
                }
            } catch (e: Exception) {
                throw e
            }
        }
    }
}