package com.kaskin.manager.Models

class IntentParams(paramName:String,paramValue:String) {
    var paramName:String
    var paramValue:String

    init{
        this.paramName = paramName
        this.paramValue = paramValue
    }
}
