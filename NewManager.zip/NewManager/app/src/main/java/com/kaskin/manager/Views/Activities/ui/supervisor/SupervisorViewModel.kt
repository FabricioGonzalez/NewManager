package com.kaskin.manager.Views.Activities.ui.supervisor

import android.arch.lifecycle.ViewModel

class SupervisorViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}