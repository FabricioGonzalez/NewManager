package com.kaskin.manager.Views.Activities.ui.settings

import android.arch.lifecycle.ViewModel

class SettingsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}