package com.kaskin.manager.Repositories

public class FileRepositories {
    public suspend fun GetExternalStorageFiles() {

    }
}