package com.kaskin.manager.Views.Activities.ui.home.visitList

import android.arch.lifecycle.ViewModel

class VisitListViewModel: ViewModel() {

}