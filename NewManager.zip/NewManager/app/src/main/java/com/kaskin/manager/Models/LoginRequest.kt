package com.kaskin.manager.Models

data class LoginRequest(val username: String, val password: String)