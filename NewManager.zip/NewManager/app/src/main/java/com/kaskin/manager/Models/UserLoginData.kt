package com.kaskin.manager.Models

data class UserLoginData(val id: Int, val setor: Int, val name: String, val password: String)