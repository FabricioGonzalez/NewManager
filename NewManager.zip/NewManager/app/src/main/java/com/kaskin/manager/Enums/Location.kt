package com.kaskin.manager.Enums

enum class Location {
Phone,
    SdCard,
    SdCard1,
    Undefined,
    Tablet,
    Card
}